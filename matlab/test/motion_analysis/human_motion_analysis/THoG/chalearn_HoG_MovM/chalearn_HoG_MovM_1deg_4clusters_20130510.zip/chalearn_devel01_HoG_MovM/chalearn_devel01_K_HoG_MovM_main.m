%----------------------------------------------------------
% dataset: quasi_lossless_format/train_data/devel01

numSeqs = 47;
%numTrainSeqs = 10;
%numTestSeqs = numSeqs - numTrainSeqs;

Mu = cell(1, numSeqs);
Kappa = cell(1, numSeqs);
Alpha = cell(1, numSeqs);

resultant_file_path = 'chalearn_devel01_K_HoG_MovM.mat';

%----------------------------------------------------------
mat_files{1,1} = struct('start_seq_idx', 0, 'start_frame_idx', 0, 'end_seq_idx', 10, 'end_frame_idx', 0, ...
	'filename', 'chalearn_devel01_K_HoG_MovM_20130410T222358.mat');

mat_files{1,2} = struct('start_seq_idx', 11, 'start_frame_idx', 0, 'end_seq_idx', 20, 'end_frame_idx', 0, ...
	'filename', 'chalearn_devel01_K_HoG_MovM_20130417T013133.mat');
mat_files{1,3} = struct('start_seq_idx', 21, 'start_frame_idx', 0, 'end_seq_idx', 21, 'end_frame_idx', 58, ...
	'filename', 'chalearn_devel01_K_HoG_MovM_20130420T181242.mat');
mat_files{1,4} = struct('start_seq_idx', 21, 'start_frame_idx', 60, 'end_seq_idx', 21, 'end_frame_idx', 0, ...
	'filename', 'chalearn_devel01_K_HoG_MovM_20130421T192555.mat');
mat_files{1,5} = struct('start_seq_idx', 22, 'start_frame_idx', 0, 'end_seq_idx', 29, 'end_frame_idx', 76, ...
	'filename', 'chalearn_devel01_K_HoG_MovM_20130421T193007.mat');
mat_files{1,6} = struct('start_seq_idx', 29, 'start_frame_idx', 78, 'end_seq_idx', 29, 'end_frame_idx', 0, ...
	'filename', 'chalearn_devel01_K_HoG_MovM_20130422T152725.mat');
mat_files{1,7} = struct('start_seq_idx', 30, 'start_frame_idx', 0, 'end_seq_idx', 31, 'end_frame_idx', 0, ...
	'filename', 'chalearn_devel01_K_HoG_MovM_20130422T152347.mat');
mat_files{1,8} = struct('start_seq_idx', 32, 'start_frame_idx', 0, 'end_seq_idx', 34, 'end_frame_idx', 84, ...
	'filename', 'chalearn_devel01_K_HoG_MovM_20130421T182534.mat');
mat_files{1,9} = struct('start_seq_idx', 35, 'start_frame_idx', 0, 'end_seq_idx', 35, 'end_frame_idx', 45, ...
	'filename', 'chalearn_devel01_K_HoG_MovM_20130422T013014.mat');
mat_files{1,10} = struct('start_seq_idx', 35, 'start_frame_idx', 47, 'end_seq_idx', 35, 'end_frame_idx', 91, ...
	'filename', 'chalearn_devel01_K_HoG_MovM_20130422T151629.mat');
mat_files{1,11} = struct('start_seq_idx', 35, 'start_frame_idx', 93, 'end_seq_idx', 35, 'end_frame_idx', 0, ...
	'filename', 'chalearn_devel01_K_HoG_MovM_20130422T163233.mat');
mat_files{1,12} = struct('start_seq_idx', 36, 'start_frame_idx', 0, 'end_seq_idx', 40, 'end_frame_idx', 23, ...
	'filename', 'chalearn_devel01_K_HoG_MovM_20130421T180317.mat');
mat_files{1,13} = struct('start_seq_idx', 40, 'start_frame_idx', 25, 'end_seq_idx', 40, 'end_frame_idx', 0, ...
	'filename', 'chalearn_devel01_K_HoG_MovM_20130422T000936.mat');
mat_files{1,14} = struct('start_seq_idx', 41, 'start_frame_idx', 0, 'end_seq_idx', 47, 'end_frame_idx', 0, ...
	'filename', 'chalearn_devel01_K_HoG_MovM_20130422T150957.mat');

for kk = 1:length(mat_files)
	dat = load(mat_files{kk}.filename);

    if mat_files{kk}.start_seq_idx > 0
        start_seq_idx = mat_files{kk}.start_seq_idx;
    else
    	start_seq_idx = 1;
    end;
    if mat_files{kk}.end_seq_idx > 0
        end_seq_idx = mat_files{kk}.end_seq_idx;
    else
    	end_seq_idx = numSeqs;
    end;

    for ii = start_seq_idx:end_seq_idx
        [numClusters numFrames] = size(dat.Mu{ii});
        [numClusters2 numFrames2] = size(dat.Kappa{ii});
        [numClusters3 numFrames3] = size(dat.Alpha{ii});
        if numClusters2 ~= numClusters || numClusters3 ~= numClusters || numFrames2 ~= numFrames || numFrames3 ~= numFrames
        	sprintf('size mismatched #1 - filename: %s, seq: %d', mat_files{kk}.filename, ii)
        	continue;
        end;

        if isempty(Mu{ii})
	    	Mu{ii} = zeros(numClusters, numFrames);
	    else
        	[rows cols] = size(Mu{ii});
	    	if rows ~= numClusters || cols ~= numFrames
        		sprintf('size mismatched #2 - filename: %s, seq: %d', mat_files{kk}.filename, ii)
	        	continue;
	    	end;
	    end;
        if isempty(Kappa{ii})
	    	Kappa{ii} = zeros(numClusters, numFrames);
	    else
        	[rows cols] = size(Kappa{ii});
	    	if rows ~= numClusters || cols ~= numFrames
        		sprintf('size mismatched #3 - filename: %s, seq: %d', mat_files{kk}.filename, iis)
	        	continue;
	    	end;
	    end;
        if isempty(Alpha{ii})
	    	Alpha{ii} = zeros(numClusters, numFrames);
	    else
        	[rows cols] = size(Alpha{ii});
	    	if rows ~= numClusters || cols ~= numFrames
        		sprintf('size mismatched #4 - filename: %s, seq: %d', mat_files{kk}.filename, ii)
	        	continue;
	    	end;
	    end;

    	if start_seq_idx == ii && mat_files{kk}.start_frame_idx > 0
    	    start_frame_idx = mat_files{kk}.start_frame_idx;
    	else
    		start_frame_idx = 1;
    	end;
    	if end_seq_idx == ii && mat_files{kk}.end_frame_idx > 0
        	end_frame_idx = mat_files{kk}.end_frame_idx;
    	else
    		end_frame_idx = numFrames;
    	end;

        for jj = start_frame_idx:end_frame_idx
        	Mu{ii}(:,jj) = dat.Mu{ii}(:,jj);
        	Kappa{ii}(:,jj) = dat.Kappa{ii}(:,jj);
        	Alpha{ii}(:,jj) = dat.Alpha{ii}(:,jj);
        end;
    end;
end;

%----------------------------------------------------------
save(resultant_file_path, 'Mu', 'Kappa', 'Alpha');
