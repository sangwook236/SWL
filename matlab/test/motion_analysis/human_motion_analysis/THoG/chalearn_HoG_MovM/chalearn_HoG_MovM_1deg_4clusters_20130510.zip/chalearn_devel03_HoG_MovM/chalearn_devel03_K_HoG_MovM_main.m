%----------------------------------------------------------
% dataset: quasi_lossless_format/train_data/devel03

numSeqs = 47;
%numTrainSeqs = 8;
%numTestSeqs = numSeqs - numTrainSeqs;

Mu = cell(1, numSeqs);
Kappa = cell(1, numSeqs);
Alpha = cell(1, numSeqs);

resultant_file_path = 'chalearn_devel03_K_HoG_MovM.mat';

%----------------------------------------------------------
mat_files{1,1} = struct('start_seq_idx', 0, 'start_frame_idx', 0, 'end_seq_idx', 10, 'end_frame_idx', 43, ...
    'filename', 'chalearn_devel03_K_HoG_MovM_20130424T185718.mat');
mat_files{1,2} = struct('start_seq_idx', 10, 'start_frame_idx', 45, 'end_seq_idx', 11, 'end_frame_idx', 14, ...
    'filename', 'chalearn_devel03_K_HoG_MovM_20130424T204755.mat');
mat_files{1,3} = struct('start_seq_idx', 11, 'start_frame_idx', 16, 'end_seq_idx', 12, 'end_frame_idx', 42, ...
    'filename', 'chalearn_devel03_K_HoG_MovM_20130424T205446.mat');
mat_files{1,4} = struct('start_seq_idx', 12, 'start_frame_idx', 44, 'end_seq_idx', 18, 'end_frame_idx', 95, ...
    'filename', 'chalearn_devel03_K_HoG_MovM_20130424T211236.mat');
mat_files{1,5} = struct('start_seq_idx', 18, 'start_frame_idx', 97, 'end_seq_idx', 23, 'end_frame_idx', 130, ...
    'filename', 'chalearn_devel03_K_HoG_MovM_20130424T225158.mat');
mat_files{1,6} = struct('start_seq_idx', 23, 'start_frame_idx', 132, 'end_seq_idx', 27, 'end_frame_idx', 15, ...
    'filename', 'chalearn_devel03_K_HoG_MovM_20130425T000048.mat');
mat_files{1,7} = struct('start_seq_idx', 27, 'start_frame_idx', 17, 'end_seq_idx', 29, 'end_frame_idx', 79, ...
    'filename', 'chalearn_devel03_K_HoG_MovM_20130425T010730.mat');
mat_files{1,8} = struct('start_seq_idx', 29, 'start_frame_idx', 81, 'end_seq_idx', 31, 'end_frame_idx', 61, ...
    'filename', 'chalearn_devel03_K_HoG_MovM_20130425T020427.mat');
mat_files{1,9} = struct('start_seq_idx', 31, 'start_frame_idx', 63, 'end_seq_idx', 31, 'end_frame_idx', 64, ...
    'filename', 'chalearn_devel03_K_HoG_MovM_20130424T222031.mat');
mat_files{1,10} = struct('start_seq_idx', 31, 'start_frame_idx', 74, 'end_seq_idx', 31, 'end_frame_idx', 76, ...
    'filename', 'chalearn_devel03_K_HoG_MovM_20130424T222611.mat');
mat_files{1,11} = struct('start_seq_idx', 31, 'start_frame_idx', 78, 'end_seq_idx', 31, 'end_frame_idx', 91, ...
    'filename', 'chalearn_devel03_K_HoG_MovM_20130424T222855.mat');
mat_files{1,12} = struct('start_seq_idx', 31, 'start_frame_idx', 93, 'end_seq_idx', 31, 'end_frame_idx', 94, ...
    'filename', 'chalearn_devel03_K_HoG_MovM_20130424T224111.mat');
mat_files{1,13} = struct('start_seq_idx', 31, 'start_frame_idx', 96, 'end_seq_idx', 31, 'end_frame_idx', 121, ...
    'filename', 'chalearn_devel03_K_HoG_MovM_20130424T224356.mat');
mat_files{1,14} = struct('start_seq_idx', 31, 'start_frame_idx', 123, 'end_seq_idx', 34, 'end_frame_idx', 78, ...
    'filename', 'chalearn_devel03_K_HoG_MovM_20130424T225449.mat');
mat_files{1,15} = struct('start_seq_idx', 34, 'start_frame_idx', 80, 'end_seq_idx', 35, 'end_frame_idx', 52, ...
    'filename', 'chalearn_devel03_K_HoG_MovM_20130424T234957.mat');
mat_files{1,16} = struct('start_seq_idx', 35, 'start_frame_idx', 54, 'end_seq_idx', 35, 'end_frame_idx', 71, ...
    'filename', 'chalearn_devel03_K_HoG_MovM_20130425T001636.mat');
mat_files{1,17} = struct('start_seq_idx', 35, 'start_frame_idx', 73, 'end_seq_idx', 35, 'end_frame_idx', 142, ...
    'filename', 'chalearn_devel03_K_HoG_MovM_20130425T002027.mat');
mat_files{1,18} = struct('start_seq_idx', 35, 'start_frame_idx', 145, 'end_seq_idx', 37, 'end_frame_idx', 23, ...
    'filename', 'chalearn_devel03_K_HoG_MovM_20130425T003146.mat');
mat_files{1,19} = struct('start_seq_idx', 37, 'start_frame_idx', 25, 'end_seq_idx', 40, 'end_frame_idx', 190, ...
    'filename', 'chalearn_devel03_K_HoG_MovM_20130425T005817.mat');
mat_files{1,20} = struct('start_seq_idx', 40, 'start_frame_idx', 192, 'end_seq_idx', 41, 'end_frame_idx', 9, ...
    'filename', 'chalearn_devel03_K_HoG_MovM_20130425T022013.mat');
mat_files{1,21} = struct('start_seq_idx', 41, 'start_frame_idx', 11, 'end_seq_idx', 44, 'end_frame_idx', 11, ...
    'filename', 'chalearn_devel03_K_HoG_MovM_20130425T023346.mat');
mat_files{1,22} = struct('start_seq_idx', 44, 'start_frame_idx', 13, 'end_seq_idx', 46, 'end_frame_idx', 2, ...
    'filename', 'chalearn_devel03_K_HoG_MovM_20130425T034127.mat');
mat_files{1,23} = struct('start_seq_idx', 46, 'start_frame_idx', 4, 'end_seq_idx', 0, 'end_frame_idx', 0, ...
    'filename', 'chalearn_devel03_K_HoG_MovM_20130425T042614.mat');

for kk = 1:length(mat_files)
	dat = load(mat_files{kk}.filename);

    if mat_files{kk}.start_seq_idx > 0
        start_seq_idx = mat_files{kk}.start_seq_idx;
    else
    	start_seq_idx = 1;
    end;
    if mat_files{kk}.end_seq_idx > 0
        end_seq_idx = mat_files{kk}.end_seq_idx;
    else
    	end_seq_idx = numSeqs;
    end;

    for ii = start_seq_idx:end_seq_idx
        [numClusters numFrames] = size(dat.Mu{ii});
        [numClusters2 numFrames2] = size(dat.Kappa{ii});
        [numClusters3 numFrames3] = size(dat.Alpha{ii});
        if numClusters2 ~= numClusters || numClusters3 ~= numClusters || numFrames2 ~= numFrames || numFrames3 ~= numFrames
        	sprintf('size mismatched #1 - filename: %s, seq: %d', mat_files{kk}.filename, ii)
        	continue;
        end;

        if isempty(Mu{ii})
	    	Mu{ii} = zeros(numClusters, numFrames);
	    else
        	[rows cols] = size(Mu{ii});
	    	if rows ~= numClusters || cols ~= numFrames
        		sprintf('size mismatched #2 - filename: %s, seq: %d', mat_files{kk}.filename, ii)
	        	continue;
	    	end;
	    end;
        if isempty(Kappa{ii})
	    	Kappa{ii} = zeros(numClusters, numFrames);
	    else
        	[rows cols] = size(Kappa{ii});
	    	if rows ~= numClusters || cols ~= numFrames
        		sprintf('size mismatched #3 - filename: %s, seq: %d', mat_files{kk}.filename, ii)
	        	continue;
	    	end;
	    end;
        if isempty(Alpha{ii})
	    	Alpha{ii} = zeros(numClusters, numFrames);
	    else
        	[rows cols] = size(Alpha{ii});
	    	if rows ~= numClusters || cols ~= numFrames
        		sprintf('size mismatched #4 - filename: %s, seq: %d', mat_files{kk}.filename, ii)
	        	continue;
	    	end;
	    end;

    	if start_seq_idx == ii && mat_files{kk}.start_frame_idx > 0
    	    start_frame_idx = mat_files{kk}.start_frame_idx;
    	else
    		start_frame_idx = 1;
    	end;
    	if end_seq_idx == ii && mat_files{kk}.end_frame_idx > 0
        	end_frame_idx = mat_files{kk}.end_frame_idx;
    	else
    		end_frame_idx = numFrames;
    	end;

        for jj = start_frame_idx:end_frame_idx
        	Mu{ii}(:,jj) = dat.Mu{ii}(:,jj);
        	Kappa{ii}(:,jj) = dat.Kappa{ii}(:,jj);
        	Alpha{ii}(:,jj) = dat.Alpha{ii}(:,jj);
        end;
    end;
end;

%----------------------------------------------------------
save(resultant_file_path, 'Mu', 'Kappa', 'Alpha');
