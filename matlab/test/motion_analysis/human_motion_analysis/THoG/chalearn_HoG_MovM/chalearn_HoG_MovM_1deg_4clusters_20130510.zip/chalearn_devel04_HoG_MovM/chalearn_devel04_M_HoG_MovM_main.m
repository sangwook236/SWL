%----------------------------------------------------------
% dataset: quasi_lossless_format/train_data/devel04

numSeqs = 47;
%numTrainSeqs = 10;
%numTestSeqs = numSeqs - numTrainSeqs;

Mu = cell(1, numSeqs);
Kappa = cell(1, numSeqs);
Alpha = cell(1, numSeqs);

resultant_file_path = 'chalearn_devel04_M_HoG_MovM.mat';

%----------------------------------------------------------
mat_files{1,1} = struct('start_seq_idx', 0, 'start_frame_idx', 0, 'end_seq_idx', 11, 'end_frame_idx', 24, ...
    'filename', 'chalearn_devel04_M_HoG_MovM_20130425T021106.mat');
mat_files{1,2} = struct('start_seq_idx', 11, 'start_frame_idx', 26, 'end_seq_idx', 15, 'end_frame_idx', 67, ...
    'filename', 'chalearn_devel04_M_HoG_MovM_20130425T032131.mat');
mat_files{1,3} = struct('start_seq_idx', 15, 'start_frame_idx', 69, 'end_seq_idx', 20, 'end_frame_idx', 125, ...
    'filename', 'chalearn_devel04_M_HoG_MovM_20130425T231802.mat');
mat_files{1,4} = struct('start_seq_idx', 20, 'start_frame_idx', 127, 'end_seq_idx', 24, 'end_frame_idx', 46, ...
    'filename', 'chalearn_devel04_M_HoG_MovM_20130426T104937.mat');
mat_files{1,5} = struct('start_seq_idx', 24, 'start_frame_idx', 48, 'end_seq_idx', 30, 'end_frame_idx', 25, ...
    'filename', 'chalearn_devel04_M_HoG_MovM_20130426T113924.mat');
mat_files{1,6} = struct('start_seq_idx', 30, 'start_frame_idx', 27, 'end_seq_idx', 32, 'end_frame_idx', 85, ...
    'filename', 'chalearn_devel04_M_HoG_MovM_20130426T132318.mat');
mat_files{1,7} = struct('start_seq_idx', 32, 'start_frame_idx', 89, 'end_seq_idx', 33, 'end_frame_idx', 55, ...
    'filename', 'chalearn_devel04_M_HoG_MovM_20130425T030508.mat');
mat_files{1,8} = struct('start_seq_idx', 33, 'start_frame_idx', 57, 'end_seq_idx', 38, 'end_frame_idx', 17, ...
    'filename', 'chalearn_devel04_M_HoG_MovM_20130425T031746.mat');
mat_files{1,9} = struct('start_seq_idx', 38, 'start_frame_idx', 19, 'end_seq_idx', 38, 'end_frame_idx', 117, ...
    'filename', 'chalearn_devel04_M_HoG_MovM_20130425T045614.mat');
mat_files{1,10} = struct('start_seq_idx', 38, 'start_frame_idx', 119, 'end_seq_idx', 0, 'end_frame_idx', 0, ...
    'filename', 'chalearn_devel04_M_HoG_MovM_20130425T231853.mat');

for kk = 1:length(mat_files)
	dat = load(mat_files{kk}.filename);

    if mat_files{kk}.start_seq_idx > 0
        start_seq_idx = mat_files{kk}.start_seq_idx;
    else
    	start_seq_idx = 1;
    end;
    if mat_files{kk}.end_seq_idx > 0
        end_seq_idx = mat_files{kk}.end_seq_idx;
    else
    	end_seq_idx = numSeqs;
    end;

    for ii = start_seq_idx:end_seq_idx
        [numClusters numFrames] = size(dat.Mu{ii});
        [numClusters2 numFrames2] = size(dat.Kappa{ii});
        [numClusters3 numFrames3] = size(dat.Alpha{ii});
        if numClusters2 ~= numClusters || numClusters3 ~= numClusters || numFrames2 ~= numFrames || numFrames3 ~= numFrames
        	sprintf('size mismatched #1 - filename: %s, seq: %d', mat_files{kk}.filename, ii)
        	continue;
        end;

        if isempty(Mu{ii})
	    	Mu{ii} = zeros(numClusters, numFrames);
	    else
        	[rows cols] = size(Mu{ii});
	    	if rows ~= numClusters || cols ~= numFrames
        		sprintf('size mismatched #2 - filename: %s, seq: %d', mat_files{kk}.filename, ii)
	        	continue;
	    	end;
	    end;
        if isempty(Kappa{ii})
	    	Kappa{ii} = zeros(numClusters, numFrames);
	    else
        	[rows cols] = size(Kappa{ii});
	    	if rows ~= numClusters || cols ~= numFrames
        		sprintf('size mismatched #3 - filename: %s, seq: %d', mat_files{kk}.filename, ii)
	        	continue;
	    	end;
	    end;
        if isempty(Alpha{ii})
	    	Alpha{ii} = zeros(numClusters, numFrames);
	    else
        	[rows cols] = size(Alpha{ii});
	    	if rows ~= numClusters || cols ~= numFrames
        		sprintf('size mismatched #4 - filename: %s, seq: %d', mat_files{kk}.filename, ii)
	        	continue;
	    	end;
	    end;

    	if start_seq_idx == ii && mat_files{kk}.start_frame_idx > 0
    	    start_frame_idx = mat_files{kk}.start_frame_idx;
    	else
    		start_frame_idx = 1;
    	end;
    	if end_seq_idx == ii && mat_files{kk}.end_frame_idx > 0
        	end_frame_idx = mat_files{kk}.end_frame_idx;
    	else
    		end_frame_idx = numFrames;
    	end;

        for jj = start_frame_idx:end_frame_idx
        	Mu{ii}(:,jj) = dat.Mu{ii}(:,jj);
        	Kappa{ii}(:,jj) = dat.Kappa{ii}(:,jj);
        	Alpha{ii}(:,jj) = dat.Alpha{ii}(:,jj);
        end;
    end;
end;

%----------------------------------------------------------
save(resultant_file_path, 'Mu', 'Kappa', 'Alpha');
