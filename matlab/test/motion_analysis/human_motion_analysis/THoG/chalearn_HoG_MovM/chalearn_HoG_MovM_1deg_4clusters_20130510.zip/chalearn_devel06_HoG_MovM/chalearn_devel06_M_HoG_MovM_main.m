%----------------------------------------------------------
% dataset: quasi_lossless_format/train_data/devel06

numSeqs = 47;
%numTrainSeqs = 10;
%numTestSeqs = numSeqs - numTrainSeqs;

Mu = cell(1, numSeqs);
Kappa = cell(1, numSeqs);
Alpha = cell(1, numSeqs);

resultant_file_path = 'chalearn_devel06_M_HoG_MovM.mat';

%----------------------------------------------------------
mat_files{1,1} = struct('start_seq_idx', 0, 'start_frame_idx', 0, 'end_seq_idx', 15, 'end_frame_idx', 3, ...
    'filename', 'chalearn_devel06_M_HoG_MovM_20130426T120632.mat');
mat_files{1,2} = struct('start_seq_idx', 15, 'start_frame_idx', 5, 'end_seq_idx', 15, 'end_frame_idx', 27, ...
    'filename', 'chalearn_devel06_M_HoG_MovM_20130426T135600.mat');
mat_files{1,3} = struct('start_seq_idx', 15, 'start_frame_idx', 29, 'end_seq_idx', 43, 'end_frame_idx', 23, ...
    'filename', 'chalearn_devel06_M_HoG_MovM_20130426T140303.mat');
mat_files{1,4} = struct('start_seq_idx', 43, 'start_frame_idx', 25, 'end_seq_idx', 46, 'end_frame_idx', 55, ...
    'filename', 'chalearn_devel06_M_HoG_MovM_20130426T164404.mat');
mat_files{1,5} = struct('start_seq_idx', 46, 'start_frame_idx', 57, 'end_seq_idx', 0, 'end_frame_idx', 0, ...
    'filename', 'chalearn_devel06_M_HoG_MovM_20130426T183832.mat');

for kk = 1:length(mat_files)
	dat = load(mat_files{kk}.filename);

    if mat_files{kk}.start_seq_idx > 0
        start_seq_idx = mat_files{kk}.start_seq_idx;
    else
    	start_seq_idx = 1;
    end;
    if mat_files{kk}.end_seq_idx > 0
        end_seq_idx = mat_files{kk}.end_seq_idx;
    else
    	end_seq_idx = numSeqs;
    end;

    for ii = start_seq_idx:end_seq_idx
        [numClusters numFrames] = size(dat.Mu{ii});
        [numClusters2 numFrames2] = size(dat.Kappa{ii});
        [numClusters3 numFrames3] = size(dat.Alpha{ii});
        if numClusters2 ~= numClusters || numClusters3 ~= numClusters || numFrames2 ~= numFrames || numFrames3 ~= numFrames
        	sprintf('size mismatched #1 - filename: %s, seq: %d', mat_files{kk}.filename, ii)
        	continue;
        end;

        if isempty(Mu{ii})
	    	Mu{ii} = zeros(numClusters, numFrames);
	    else
        	[rows cols] = size(Mu{ii});
	    	if rows ~= numClusters || cols ~= numFrames
        		sprintf('size mismatched #2 - filename: %s, seq: %d', mat_files{kk}.filename, ii)
	        	continue;
	    	end;
	    end;
        if isempty(Kappa{ii})
	    	Kappa{ii} = zeros(numClusters, numFrames);
	    else
        	[rows cols] = size(Kappa{ii});
	    	if rows ~= numClusters || cols ~= numFrames
        		sprintf('size mismatched #3 - filename: %s, seq: %d', mat_files{kk}.filename, ii)
	        	continue;
	    	end;
	    end;
        if isempty(Alpha{ii})
	    	Alpha{ii} = zeros(numClusters, numFrames);
	    else
        	[rows cols] = size(Alpha{ii});
	    	if rows ~= numClusters || cols ~= numFrames
        		sprintf('size mismatched #4 - filename: %s, seq: %d', mat_files{kk}.filename, ii)
	        	continue;
	    	end;
	    end;

    	if start_seq_idx == ii && mat_files{kk}.start_frame_idx > 0
    	    start_frame_idx = mat_files{kk}.start_frame_idx;
    	else
    		start_frame_idx = 1;
    	end;
    	if end_seq_idx == ii && mat_files{kk}.end_frame_idx > 0
        	end_frame_idx = mat_files{kk}.end_frame_idx;
    	else
    		end_frame_idx = numFrames;
    	end;

        for jj = start_frame_idx:end_frame_idx
        	Mu{ii}(:,jj) = dat.Mu{ii}(:,jj);
        	Kappa{ii}(:,jj) = dat.Kappa{ii}(:,jj);
        	Alpha{ii}(:,jj) = dat.Alpha{ii}(:,jj);
        end;
    end;
end;

%----------------------------------------------------------
save(resultant_file_path, 'Mu', 'Kappa', 'Alpha');
