%----------------------------------------------------------
% dataset: quasi_lossless_format/train_data/devel09

numSeqs = 47;
%numTrainSeqs = 9;
%numTestSeqs = numSeqs - numTrainSeqs;

Mu = cell(1, numSeqs);
Kappa = cell(1, numSeqs);
Alpha = cell(1, numSeqs);

resultant_file_path = 'chalearn_devel09_M_HoG_MovM.mat';

%----------------------------------------------------------
mat_files{1,1} = struct('start_seq_idx', 0, 'start_frame_idx', 0, 'end_seq_idx', 2, 'end_frame_idx', 17, ...
    'filename', 'chalearn_devel09_M_HoG_MovM_20130426T230503.mat');
mat_files{1,2} = struct('start_seq_idx', 2, 'start_frame_idx', 21, 'end_seq_idx', 3, 'end_frame_idx', 36, ...
    'filename', 'chalearn_devel09_M_HoG_MovM_20130426T232803.mat');
mat_files{1,3} = struct('start_seq_idx', 3, 'start_frame_idx', 38, 'end_seq_idx', 8, 'end_frame_idx', 5, ...
    'filename', 'chalearn_devel09_M_HoG_MovM_20130426T234032.mat');
mat_files{1,4} = struct('start_seq_idx', 8, 'start_frame_idx', 7, 'end_seq_idx', 25, 'end_frame_idx', 0, ...
    'filename', 'chalearn_devel09_M_HoG_MovM_20130427T001301.mat');
mat_files{1,5} = struct('start_seq_idx', 26, 'start_frame_idx', 2, 'end_seq_idx', 31, 'end_frame_idx', 91, ...
    'filename', 'chalearn_devel09_M_HoG_MovM_20130427T135425.mat');
mat_files{1,6} = struct('start_seq_idx', 31, 'start_frame_idx', 93, 'end_seq_idx', 31, 'end_frame_idx', 94, ...
    'filename', 'chalearn_devel09_M_HoG_MovM_20130426T233003.mat');
mat_files{1,7} = struct('start_seq_idx', 32, 'start_frame_idx', 0, 'end_seq_idx', 33, 'end_frame_idx', 37, ...
    'filename', 'chalearn_devel09_M_HoG_MovM_20130426T233156.mat');
mat_files{1,8} = struct('start_seq_idx', 33, 'start_frame_idx', 39, 'end_seq_idx', 33, 'end_frame_idx', 45, ...
    'filename', 'chalearn_devel09_M_HoG_MovM_20130427T000111.mat');
mat_files{1,9} = struct('start_seq_idx', 33, 'start_frame_idx', 47, 'end_seq_idx', 34, 'end_frame_idx', 123, ...
    'filename', 'chalearn_devel09_M_HoG_MovM_20130427T000948.mat');
mat_files{1,10} = struct('start_seq_idx', 34, 'start_frame_idx', 125, 'end_seq_idx', 37, 'end_frame_idx', 73, ...
    'filename', 'chalearn_devel09_M_HoG_MovM_20130427T003722.mat');
mat_files{1,11} = struct('start_seq_idx', 37, 'start_frame_idx', 75, 'end_seq_idx', 39, 'end_frame_idx', 37, ...
    'filename', 'chalearn_devel09_M_HoG_MovM_20130427T015143.mat');
mat_files{1,12} = struct('start_seq_idx', 39, 'start_frame_idx', 39, 'end_seq_idx', 39, 'end_frame_idx', 53, ...
    'filename', 'chalearn_devel09_M_HoG_MovM_20130427T022429.mat');
mat_files{1,13} = struct('start_seq_idx', 39, 'start_frame_idx', 57, 'end_seq_idx', 46, 'end_frame_idx', 11, ...
    'filename', 'chalearn_devel09_M_HoG_MovM_20130427T135944.mat');
mat_files{1,14} = struct('start_seq_idx', 46, 'start_frame_idx', 13, 'end_seq_idx', 46, 'end_frame_idx', 104, ...
    'filename', 'chalearn_devel09_M_HoG_MovM_20130427T154331.mat');
mat_files{1,15} = struct('start_seq_idx', 46, 'start_frame_idx', 109, 'end_seq_idx', 47, 'end_frame_idx', 86, ...
    'filename', 'chalearn_devel09_M_HoG_MovM_20130427T160819.mat');

for kk = 1:length(mat_files)
	dat = load(mat_files{kk}.filename);

    if mat_files{kk}.start_seq_idx > 0
        start_seq_idx = mat_files{kk}.start_seq_idx;
    else
    	start_seq_idx = 1;
    end;
    if mat_files{kk}.end_seq_idx > 0
        end_seq_idx = mat_files{kk}.end_seq_idx;
    else
    	end_seq_idx = numSeqs;
    end;

    for ii = start_seq_idx:end_seq_idx
        [numClusters numFrames] = size(dat.Mu{ii});
        [numClusters2 numFrames2] = size(dat.Kappa{ii});
        [numClusters3 numFrames3] = size(dat.Alpha{ii});
        if numClusters2 ~= numClusters || numClusters3 ~= numClusters || numFrames2 ~= numFrames || numFrames3 ~= numFrames
        	sprintf('size mismatched #1 - filename: %s, seq: %d', mat_files{kk}.filename, ii)
        	continue;
        end;

        if isempty(Mu{ii})
	    	Mu{ii} = zeros(numClusters, numFrames);
	    else
        	[rows cols] = size(Mu{ii});
	    	if rows ~= numClusters || cols ~= numFrames
        		sprintf('size mismatched #2 - filename: %s, seq: %d', mat_files{kk}.filename, ii)
	        	continue;
	    	end;
	    end;
        if isempty(Kappa{ii})
	    	Kappa{ii} = zeros(numClusters, numFrames);
	    else
        	[rows cols] = size(Kappa{ii});
	    	if rows ~= numClusters || cols ~= numFrames
        		sprintf('size mismatched #3 - filename: %s, seq: %d', mat_files{kk}.filename, ii)
	        	continue;
	    	end;
	    end;
        if isempty(Alpha{ii})
	    	Alpha{ii} = zeros(numClusters, numFrames);
	    else
        	[rows cols] = size(Alpha{ii});
	    	if rows ~= numClusters || cols ~= numFrames
        		sprintf('size mismatched #4 - filename: %s, seq: %d', mat_files{kk}.filename, ii)
	        	continue;
	    	end;
	    end;

    	if start_seq_idx == ii && mat_files{kk}.start_frame_idx > 0
    	    start_frame_idx = mat_files{kk}.start_frame_idx;
    	else
    		start_frame_idx = 1;
    	end;
    	if end_seq_idx == ii && mat_files{kk}.end_frame_idx > 0
        	end_frame_idx = mat_files{kk}.end_frame_idx;
    	else
    		end_frame_idx = numFrames;
    	end;

        for jj = start_frame_idx:end_frame_idx
        	Mu{ii}(:,jj) = dat.Mu{ii}(:,jj);
        	Kappa{ii}(:,jj) = dat.Kappa{ii}(:,jj);
        	Alpha{ii}(:,jj) = dat.Alpha{ii}(:,jj);
        end;
    end;
end;

%----------------------------------------------------------
save(resultant_file_path, 'Mu', 'Kappa', 'Alpha');
